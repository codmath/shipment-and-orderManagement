package com.practice.ordship.test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import org.testng.annotations.Test;

import com.practice.ordship.entity.OrderManagement;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class Test_1 {
@Test
public void TestallGetData() {
	Response res=RestAssured.get("http://localhost:3262/order/getAllOrder");
	System.out.println(res.getStatusCode());
	System.out.println(res.getTime());
	System.out.println(res.getContentType());
	System.out.println("Get testalldata API testcases Passed successfully");

}
@Test
public void Test_fun_1() {
	int ord_id=1;
	Response res=given().pathParam("ord_id", ord_id)
        .when()
            .get("http://localhost:3262/order/getOrderData/{ord_id}");
	System.out.println(res.getStatusCode());
	System.out.println(res.getContentType());
	System.out.println(res.getStatusLine());
	System.out.println("Get OrderbyId tsestcases Passed successfully");
}
@Test
public void testCreateOrder() {
    OrderManagement ordmgt = new OrderManagement( 1, // id
    	    "ORD123", // orderNumber
    	    "Online", // order_type
    	    "ProductABC", // order_product
    	    "2", // quantity
    	    "John Doe", // customer_name
    	    123, // customer_id
    	    "2024-03-18");

    Response res = given()
            .contentType(ContentType.JSON)
            .body(ordmgt)
        .when()
            .post("http://localhost:3262/order/CreateOrder");

    System.out.println(res.getStatusCode());
	System.out.println(res.getContentType());
	System.out.println(res.getStatusLine());
	System.out.println("CreateOrder API Passed successfully");

    // You can add additional assertions here if needed
}
@Test
public void testUpdateOrder() {
    // Prepare the test data
    OrderManagement updatedOrder = new OrderManagement(
            1, // id
            "ORD12tg3", // orderNumber
            "Onlinge", // order_type
            "ProducgtABC", // order_product
            "25", // quantity
            "Johgn Doe", // customer_name
            1234, // customer_id
            "2024-04-18" // order_date
    );

    // Send the PUT request
    Response res = given()
            .contentType("application/json")
            .body(updatedOrder)
        .when()
            .put("http://localhost:3262/UpdateOrder/{ord_id}", 1);
    

    System.out.println(res.getStatusCode());
	System.out.println(res.getContentType());
	System.out.println(res.getStatusLine());
	System.out.println("Update order API test passed successfully");

  
}
@Test
public void testDeleteOrder() {
    // Send the DELETE request
    Response res = given()
            .contentType("application/json")
        .when()
            .delete("http://localhost:3262/DeleteOrder/{ord_id}", 1);
    System.out.println(res.getStatusCode());
	System.out.println(res.getContentType());
	System.out.println(res.getStatusLine());
	System.out.println("delete  order API test passed successfully");

    
}

}
