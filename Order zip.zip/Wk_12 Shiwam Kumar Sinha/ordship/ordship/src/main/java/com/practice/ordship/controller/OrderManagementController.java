package com.practice.ordship.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.practice.ordship.entity.OrderManagement;
import com.practice.ordship.entity.Shipment;
import com.practice.ordship.services.OrderManagementService;

@RestController
@RequestMapping("/order")
public class OrderManagementController {
	@Autowired
	private OrderManagementService ordermgtserv;
	@Autowired
	private RestTemplate restTem;
	private final String myURL="http://localhost:3262";
	//shipment placed
	@PostMapping("/placeOrderShipment")
	public ResponseEntity<String> function_5(@RequestBody Shipment shipment) {
		String newURL=myURL+"/shipment/placedorder";
		ResponseEntity<String> res_5=restTem.postForEntity(newURL,  shipment, String.class);
		return ResponseEntity.ok(res_5.getBody());	
	}
	@PostMapping("/CreateOrder")
	public String function_1(@RequestBody OrderManagement ordmgt) {
		String res_1=this.ordermgtserv.CreateOrderData(ordmgt);
		return res_1;
	}
	//method to get all the data in the OrderManagement
	@GetMapping("/getAllOrder")
	public List<OrderManagement> function_0(){
		List<OrderManagement> res_0=this.ordermgtserv.getSabhiOrder();
		return res_0;
	}
	//method to read the data from orderId
	@GetMapping("/getOrderData/{ord_id}")
	public String function_2(@PathVariable int ord_id) {
		String res_2=this.ordermgtserv.findOrders(ord_id);
		return res_2;
	}
	//method to update the data of order by Id
	@PutMapping("/UpdateOrder/{ord_id}")
	public String function_3(@PathVariable int ord_id, @RequestBody OrderManagement ordermgt) {
		String res_3=this.ordermgtserv.UpdateOrder(ord_id, ordermgt);
		return res_3;
	}
	//method to delete the data of order by id
	@DeleteMapping("/DeleteOrder/{ord_id}")
	public String function_4(@PathVariable int ord_id) {
		String res_4=this.ordermgtserv.deleteDataOrder(ord_id);
		return res_4;
	}
	
	

	
}
