package com.practice.ordship.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.practice.ordship.entity.OrderManagement;
import com.practice.ordship.exceptions.OrderNotFoundException;
import com.practice.ordship.repo.OrderManagementRepo;

@Service
public class OrderManagementService {
	@Autowired
	private OrderManagementRepo myOrderRepo;

	public String CreateOrderData(OrderManagement ordmgt) {
		// TODO Auto-generated method stub
		OrderManagement myOrder=this.myOrderRepo.save(ordmgt);
		return "order Created Successfully";
		
	}

	public String findOrders(int ord_id) {
		// TODO Auto-generated method stub
		try {
	        Optional<OrderManagement> myOrderdetailsManagement = this.myOrderRepo.findById(ord_id);
	        if (myOrderdetailsManagement == null) {
	            throw new OrderNotFoundException("Order not found");
	        }
	        return "Got the data successfully";
	    } catch (OrderNotFoundException e) {
	        return "Order not found";
	    } catch (Exception e) {
	        return "An error occurred";
	    }
		
	}

	public String UpdateOrder(int ord_id, OrderManagement ordermgt) {
		// TODO Auto-generated method stub
		Optional<OrderManagement> optionalOrder=this.myOrderRepo.findById(ord_id);
		//updation
		if(optionalOrder.isPresent()) {
			OrderManagement existedOrder=optionalOrder.get();
			existedOrder.setOrderNumber(ordermgt.getOrderNumber());
			existedOrder.setOrder_type(ordermgt.getOrder_type());
			existedOrder.setOrder_product(ordermgt.getOrder_product());
			existedOrder.setQuantity(ordermgt.getQuantity());
			existedOrder.setCustomer_name(ordermgt.getCustomer_name());
			existedOrder.setCustomer_id(ordermgt.getCustomer_id());
			existedOrder.setOrder_date(ordermgt.getOrder_date());
			this.myOrderRepo.save(existedOrder);
			return "data updated Successfully";
			
		}
		else {
			throw new OrderNotFoundException("order not updated");
		}
		
	}

	public String deleteDataOrder(int ord_id) {
		// TODO Auto-generated method stub
		Optional<OrderManagement> optionalOrder=this.myOrderRepo.findById(ord_id);
		if(optionalOrder.isPresent()) {
			OrderManagement existingOrder=optionalOrder.get();
			this.myOrderRepo.delete(existingOrder);
			return "Deleted Successfully";
	
		}
		else {
			throw new OrderNotFoundException("order not deleted");

		}
	}

	public List<OrderManagement> getSabhiOrder() {
		// TODO Auto-generated method stub
		List<OrderManagement> myAllData=this.myOrderRepo.findAll();
		return myAllData;
	}

}
