package com.practice.ordship.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
@Entity
@Table(name="shipment_service")
public class Shipment {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private int shipment_id;
@Column
private String Shipment_address;
@Column 
private String shipment_date;
@Column
private String shipmenter_name;
public int getShipment_id() {
	return shipment_id;
}
public void setShipment_id(int shipment_id) {
	this.shipment_id = shipment_id;
}
public String getShipment_address() {
	return Shipment_address;
}
public void setShipment_address(String shipment_address) {
	Shipment_address = shipment_address;
}
public String getShipment_date() {
	return shipment_date;
}
public void setShipment_date(String shipment_date) {
	this.shipment_date = shipment_date;
}
public String getShipmenter_name() {
	return shipmenter_name;
}
public void setShipmenter_name(String shipmenter_name) {
	this.shipmenter_name = shipmenter_name;
}
public Shipment(int shipment_id, String shipment_address, String shipment_date, String shipmenter_name) {
	super();
	this.shipment_id = shipment_id;
	Shipment_address = shipment_address;
	this.shipment_date = shipment_date;
	this.shipmenter_name = shipmenter_name;
}
public Shipment() {
	super();
	// TODO Auto-generated constructor stub
}



}
