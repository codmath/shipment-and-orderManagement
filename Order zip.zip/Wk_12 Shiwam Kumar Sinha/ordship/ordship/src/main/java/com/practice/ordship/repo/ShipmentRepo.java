package com.practice.ordship.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.practice.ordship.entity.Shipment;

@Repository
public interface ShipmentRepo extends JpaRepository<Shipment, Integer> {
	

}
