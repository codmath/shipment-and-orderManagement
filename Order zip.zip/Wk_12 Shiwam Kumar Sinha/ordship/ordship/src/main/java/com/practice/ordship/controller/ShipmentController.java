package com.practice.ordship.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.practice.ordship.entity.Shipment;
import com.practice.ordship.services.ShipmentService;

@RestController
@RequestMapping("/shipment")
public class ShipmentController {
	@Autowired
	private ShipmentService shipServe;
	@PostMapping("/placedorder")
	public String fun_1(@RequestBody Shipment tempShip) {
		String result_1=this.shipServe.addData(tempShip);
		return result_1;
	}

}
