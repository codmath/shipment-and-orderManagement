package com.practice.ordship.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.practice.ordship.entity.Shipment;
import com.practice.ordship.repo.ShipmentRepo;

@Service
public class ShipmentService {
	@Autowired
	private ShipmentRepo shiprepo;
	

	public String addData(Shipment ship) {
		// TODO Auto-generated method stub
		this.shiprepo.save(ship);
		return "shipment successfully added";
	}


	
	

}
