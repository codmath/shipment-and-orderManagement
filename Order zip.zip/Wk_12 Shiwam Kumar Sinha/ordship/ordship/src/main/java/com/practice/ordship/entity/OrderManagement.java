package com.practice.ordship.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="ordermanagement")
public class OrderManagement {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Column
    private String orderNumber;
    @Column
    private String order_type;
    @Column
    private String order_product;
    @Column
    private String quantity;
    @Column
    private String customer_name;
    @Column 
    private int customer_id;
    @Column
    private String Order_date;
	public OrderManagement(int id, String orderNumber, String order_type, String order_product, String quantity,
			String customer_name, int customer_id, String order_date) {
		super();
		this.id = id;
		this.orderNumber = orderNumber;
		this.order_type = order_type;
		this.order_product = order_product;
		this.quantity = quantity;
		this.customer_name = customer_name;
		this.customer_id = customer_id;
		this.Order_date = order_date;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	public String getCustomer_name() {
		return customer_name;
	}
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}
	public int getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}
	public String getOrder_date() {
		return Order_date;
	}
	public void setOrder_date(String order_date) {
		Order_date = order_date;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getOrderNumber() {
		return orderNumber;
	}
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}
	public String getOrder_type() {
		return order_type;
	}
	public void setOrder_type(String order_type) {
		this.order_type = order_type;
	}
	public String getOrder_product() {
		return order_product;
	}
	public void setOrder_product(String order_product) {
		this.order_product = order_product;
	}
	
	public OrderManagement() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    

}
