package com.practice.ordship;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrdshipApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrdshipApplication.class, args);
	}

}
