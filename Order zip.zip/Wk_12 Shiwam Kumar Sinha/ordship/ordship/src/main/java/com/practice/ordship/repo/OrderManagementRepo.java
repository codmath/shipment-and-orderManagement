package com.practice.ordship.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.practice.ordship.entity.OrderManagement;

@Repository
public interface OrderManagementRepo extends JpaRepository<OrderManagement, Integer> {

}
